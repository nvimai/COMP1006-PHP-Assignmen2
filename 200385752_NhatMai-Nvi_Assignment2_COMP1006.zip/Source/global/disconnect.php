<?php
// Disconnect
$conn = null;
?>